package ga;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

/** Clase AlgoritmoGenetico
 * <pre>
 * Genetic algorithm; loosely based on the GA implementation at AIMA-Java
 * </pre>
 * 
 * @author Ines y los alumnos
 * 
 * @param <A>
 *            the type of the alphabet used in the representation of the
 *            individuals in the population (this is to provide flexibility in
 *            terms of how a problem can be encoded).
 * @version 2019.10.*
 */
public class AlgoritmoGenetico<A> {
	// ATRIBUTOS
	protected int tamPob; // tamanio de la poblacion
	protected int iteraciones;// numero de iteraciones de una ejecucion del algoritmo
	protected int individualLength; // longitud de un cromosoma
	protected List<A> finiteAlphabet; // alfabeto (simbolos que froman el cromosoma)
	protected double probMutacion; // probabilidad de mutacion
	protected double probCruce;// probabilidad de cruce; si ==1, cruce incondicional
	// Guardo una traza con el fitness medio y el fitness del mejor individuo en cada generacion
	protected List<Double> fitnessMejores = new LinkedList<Double>();
	protected List<Double >fitnessMedios = new LinkedList<Double>();
	// CONSTRUCTOR
	public AlgoritmoGenetico(int individualLength, Collection<A> finiteAlphabet, 
			double crossoverProbability, 
			double mutationProbability, int popSize ) {
		this.individualLength = individualLength;
		this.finiteAlphabet = new ArrayList<A>(finiteAlphabet);
		setProbMutacion(mutationProbability);
		setProbCruce(crossoverProbability);
		this.tamPob = popSize;

	}

	// OBSERVADORES Y MODIFICADORES

	/**
	 * setter del atributo para la probabilidad de cruce
	 * @param probCruce, el nuevo valor para la probabilidad de cruce; ha de estar entre 0 y 1
	 */
	public void setProbCruce(double pc) {
		assert(pc >= 0.0 && pc <= 1.0);
		this.probCruce=pc;
	}

	/**
	 * @return la probabilidad de cruce
	 */
	public double getProbCruce() {
		return probCruce;
	}

	/**
	 * setter del atributo para la probabilidad de cruce
	 * @param probMutacion, el nuevo valor para la probabilidad de mutacion; ha de estar entre 0 y 1
	 */
	public void setProbMutacion(double pm) {
		assert(pm >= 0.0 && pm <= 1.0);
		this.probMutacion=pm;
	}

	/**
	 * @return la probabilidad de mutacion
	 */
	public double getProbMutacion() {
		return probMutacion;
	}


	/**
	 * resetea las iteraciones a 0
	 */
	public void resetIteraciones() {
		this.iteraciones=0;
	}


	/**
	 * incrementa en 1 el numero de iteraciones
	 */
	public void incrementaIteraciones() {
		this.iteraciones++;
	}
	/**
	 * Observador del numero de iteraciones the genetic algorithm.
	 * 
	 * @return the number of iteraciones of the genetic algorithm.
	 */
	public int getIteraciones() {
		return iteraciones;
	}

	// METODOS DEL GA
	/**
	 * lanzaGA()
	 * Método que lanza una ejecución del GA:
	 * Generates an initial population, then starts the genetic algorithm and stops after a specified number of
	 * iterations.
	 * @param opG un OpGeneracion (para generar la poblacion inicial)
	 * @param fitnessFn la funcion de fitness (para evaluar los cromosomas)
	 * @param maxIterations el numero maximo de iteraciones del GA (criterio de parada)
	 * @param opCross un opCruce (para realizar los cruces)
	 * @param opM un OpMutacion (para realizar la mutacion)
	 * @param opSel un OpSeleccion (para seleccionar individuos de la poblacion para cruzar)
	 * @return el mejor individuo de la ultima poblacion (la solucion)
	 */
	public Individuo<A> lanzaGA( OpGeneracion<A> opG, Fitness<A> fitnessFn, 
			final int maxIterations, 
			OpCruce<A> opCross, OpMutacion<A> opM, OpSeleccion<A> opSel ) {
		// generamos poblacion inicial
		List<Individuo<A>> pob = generaPobInicial(opG, tamPob);

		List<Individuo<A>> mejoresHijos = new LinkedList<Individuo<A>>();
		evaluaPoblacion(pob,fitnessFn);
		Individuo<A> x, y, hijo, mejor;
		// hay que rellenar esto para que se lance un algoritmo genetico
		// con los operadores y parametros dados segun lo explicado en clase
		for(int nGen=0; nGen<=maxIterations; nGen++) {
			// Nueva Generacion
			List<Individuo<A>> npob = new LinkedList<Individuo<A>>(); //  conjunto vacio
			// ******************** (QUITAR ANTES DE ENVIAR) ********************
			// Como tarda bastante, imprimo las generaciones que se van formando 
			System.out.println("Generacion: " + nGen);
			// ******************** (QUITAR ANTES DE ENVIAR) ********************
			for(int i=0; i<pob.size(); i++) {
				
				// Aplicamos el operador de seleccion
				x = opSel.apply(pob);	// seleccion dependiente del fitness
				y = opSel.apply(pob);
				
				// Aplicamos el operador de cruce (puede adaptarse para generar 2 hijos)
				if(Util.randomDouble()< probCruce) {	// con probabilidad probCruce cruzamos
					hijo = opCross.apply(1, x, y).get(0);
				}else {
					hijo = x;
				}
				// Aplicamos el operador de mutacion
				if(Util.randomDouble() < probMutacion) {
					hijo = opM.apply(hijo);
				}
				// Añadir hijo a npob
				npob.add(hijo);
			}
			mejor = mejorIndividuo(pob, fitnessFn);
			// Guardo el mejor elemento de la generacion en la lista
			fitnessMejores.add(mejor.getFitness());
			// Guardo el fitness medio de la poblacion
			fitnessMedios.add(getFitnessMedio(pob, fitnessFn));
			// Guardo el mejor hijo de la generacion
			mejoresHijos.add(mejorIndividuo(pob, fitnessFn));
			// Anhadimos a la nueva poblacion el mejor individuo de la anterior.
			//Elitismo
			//npob.set(0, mejor);
			// Evalua poblacion (npob)
			evaluaPoblacion(npob, fitnessFn);
			// Aplicamos el operador de reemplazo en caso de tener la operacion de reemplazo:
			// opReml.apply(pob,npob); Reemplazo generacional con o sin elitismo
			pob = npob;
			
		}
		mejoresHijos.add(mejorIndividuo(pob, fitnessFn));
		fitnessMejores.add(mejorIndividuo(pob, fitnessFn).getFitness());
		fitnessMedios.add(getFitnessMedio(pob, fitnessFn));

// ******************** (QUITAR ANTES DE ENVIAR) ********************
//		Imprimir por pantalla para ver los valores medios y mejores 
		System.out.println("Media por generacion: ");
		for(Double i: fitnessMedios) {
			System.out.println(i);
		}
		System.out.println("Mejores hijos por generacion: ");
		for(Double i: fitnessMejores) {
			System.out.println(i);

		}
// ******************** (QUITAR ANTES DE ENVIAR) ********************

		return mejorIndividuo(pob, fitnessFn); // El mejor individuo en pob segun fitnessFn
	}
	/**
	 * Metodo auxiliar para calcular el mejor individuo de una poblacion segun la funcion fitness
	 * @param pob, poblacion en la que buscar el mejor individuo
	 * @param fitnessFn, funcion fitness 
	 * @return Individuo<A>, el mejor individuo de la poblacion segun la funcion fitness
	 */
	private Individuo<A> mejorIndividuo(List<Individuo<A>> pob, Fitness<A> fitnessFn) {
		Individuo<A> mejorInd = pob.get(0);
		for( Individuo<A> cromosoma: pob ) {
			if(fitnessFn.apply(mejorInd) < fitnessFn.apply(cromosoma)) {
				// se hace en base al problema TSP por lo que en la funcion fitness
				// se busca el minimo coste posible
				mejorInd = cromosoma;
			}
		}
		return mejorInd;
	}

	/**
	 * Metodo auxiliar para calcular el fitness medio de cada generacion
	 * @param poblacion poblacion sobre la que calcular la media
	 * @param fitnessFn funcion fitness a aplicar sobre la generacion
	 * @return valor medio del fitness de la poblacion
	 */
	public double getFitnessMedio(List<Individuo<A>> poblacion, Fitness<A> fitnessFn){  
		double media = 0;
		for(int i = 0; i<poblacion.size(); i++) {
			media += fitnessFn.apply(poblacion.get(i));
		}

		return media/poblacion.size();
	}

	/**
	 * generateInitPopulation()
	 * Metodo para generar la poblacion inicial
	 * @param opG el operador de generacion de individuos
	 * @param tamPob el tamanio de la poblacion
	 * @return initPopulation la poblacion inicial
	 */
	protected List<Individuo<A>> generaPobInicial(OpGeneracion<A> opG, int popSize) {
		List<Individuo<A>> initPopulation = new ArrayList<Individuo<A>>(popSize);
		for( int i=0; i<popSize; i++ ) {
			initPopulation.add(opG.apply());
		}
		return initPopulation;
	}

	/** Metodo para evaluar una poblacion, actualizando el valor de fitness de cada individuo
	 * @param pob, una poblacion
	 * @param fitnessF, una funcion de fitness
	 */
	protected void evaluaPoblacion( List<Individuo<A>> pob, Fitness<A> fitnessF ) {
		// recorremos la poblacion y vamos evaluando cada individuo y guardando su fitness
		for( Individuo<A> cromosoma: pob ) {
			cromosoma.setFitness(fitnessF.apply(cromosoma));
		}
	}

}