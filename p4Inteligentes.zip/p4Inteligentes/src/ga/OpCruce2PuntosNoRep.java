package ga;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase OpCruce2PuntosNoRep
 * implements 2-point crossover with no repetitions (OX)
 * @param A el tipo de los elementos que componen un crosomosoma (genes)
 * @author Ines
 * @version 2018.11.*
 */
public class OpCruce2PuntosNoRep<A> extends OpCruce<A> {


	/* (non-Javadoc)
	 * @see ga.OpCruce#apply(int, ga.Individuo, ga.Individuo)
	 */
	@Override
	public List<Individuo<A>> apply(int nchildren, Individuo<A> parent1, Individuo<A> parent2) {
		
		assert(nchildren>0 && nchildren<=2); // can generate 1 or 2 children
		List<Individuo<A>> children = new ArrayList<Individuo<A>>(nchildren); // list of children
		int c1 = Util.randomInt(parent1.length()); // first crossover point
		int c2 = Util.randomInt(parent1.length()); // second crossover point
		if( c1 > c2 ) {// swap so c1 <= c2
			int aux =c1;
			c1=c2;
			c2=aux;
		}
		children.add(0, cross2(c1, c2, parent1,parent2));
		if( nchildren == 2 ) {
			children.add(1, cross2(c1,c2,parent2,parent1)); // exchange parent roles to produce 2nd child
		}		
		return children;	
	}
	
	/**
	 * Operador de cruce: CRUCE EN DOS PUNTOS
	 * @param c1, el primer punto de cruce ( 0<=c1<Individuo.length() )
	 * @param c2, el segundo punto de cruce ( 0<=c2<Individuo.length() && c1<=c2)
	 * @param x, un cromosoma
	 * @param y, otro cromosoma
	 * @return el hijo de x e y
	 */
	private Individuo<A> cross2(int c1, int c2, Individuo<A> x, Individuo<A> y) {
		assert(c1 <= c2 ); 
		List<A> xChromosome = x.getRepresentation(); // chromosome x
		List<A> yChromosome = y.getRepresentation(); // chromosome y
		List<A> childChromosome = new ArrayList<A>(xChromosome); // child chromosome; initially identical to parent 1
		// The genes "outside" substring from c1 to c2 should be copied from the second parent, in the same relative order
		int k = 0; // index in child where we must copy gene from second parent (y)
		int i = 0; // index of element to be copied (or not) in second parent (y)
		// fill positions from 0 to c1 with genes from second parent
		while( k < c1 ) {
			int j=c1; // index to move in substring copied from first parent (x)
			while( j<c2 && yChromosome.get(i)!=xChromosome.get(j)) j++; // search ith gene from y in substring copied from x
			if( j == c2 ) {// ith gene from y is not already in child
				childChromosome.set(k, yChromosome.get(i)); // copy ith element from y in position k
				// move to next position in child
				k++;
			}
			i++;// move to next gene in second parent y
		}
		// fill positions from c2 to end with genes from second parent
		k=c2;
		while( k<childChromosome.size() ) {
			int j=c1; // index to move in substring copied from first parent (x)
			while( j<c2 && yChromosome.get(i)!=xChromosome.get(j)) j++; // search ith gene from y in substring copied from x
			if( j == c2 ) {// ith gene from y is not already in child
				childChromosome.set(k, yChromosome.get(i)); // copy ith element from y in position k
				// move to next position in child
				k++;
			}			
			i++; // move to next gene in second parent y
		}
		Individuo<A> child = new Individuo<A>(childChromosome);
		return child;
	}

}
