package tsp;

import ga.Fitness;
import ga.Individuo;

/**
 * Clase para implementar el fitness para una "solucion" a un TSP
 * @author Ines
 * @version 2018.11.*
 */
public class FitnessTSP implements Fitness<Integer> {
	
	private static OpDecodTSP decoder; // necesita un operador de decodificacion para generar (y evaluar) un fenotipo a partir de un cromosoma

	/**
	 * Constructor
	 * @param p un problema TSP (lo necesitamos para decodificar el cromosoma)
	 */
	public FitnessTSP(ProblemaTSP p) {
		decoder = new OpDecodTSP(p);
	}

	@Override
	public double apply(Individuo<Integer> individual) {
		SolucionTSP sol = decoder.apply(individual); // transformamos el cromosoma en una solucion
		return (sol.getCoste()!=0 ? 1.0/sol.getCoste() : Double.MAX_VALUE); // devolvemos el inverso del coste de la solucion
	}

}
