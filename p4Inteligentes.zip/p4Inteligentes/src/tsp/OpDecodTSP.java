package tsp;

import ga.Individuo;

/**
 * Clase OpDecodTSP
 * Clase que decodifica un cromosoma y obtiene un fenotipo (un tour o solucion al problema)
 * @author Ines
 * @version 2018.11.*
 */
public class OpDecodTSP {
	// ATRIBUTO
	private static ProblemaTSP p; // los datos: ciudades, distancias...

	/**
	 * Constructor
	 * @param p el problema
	 */
	public OpDecodTSP(ProblemaTSP p) {
		OpDecodTSP.p = p;
	}
	
	/**
	 * metodo apply
	 * @param ind el individuo (cromosoma o genotipo)
	 * @return la solucion que representa (fenotipo)
	 */
	public SolucionTSP apply( Individuo<Integer> ind) {
		// inicia solucion con solo el origen
		SolucionTSP sol = new SolucionTSP(p);
		// aniade las ciudades en el orden marcado por el individuo
		for( Integer i: ind.getRepresentation() ) {
			sol.aniade( p.getCiudad(i) ); // aniade ciudad i-esima
		}
		// "cierra" la ruta de la solucion volviendo al origen
		sol.aniade(p.getOrigen());
		return sol;
	}

}
