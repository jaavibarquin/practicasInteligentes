
package tsp;

import ga.*;

/**
 * Clase TesterTSP
 * Clase para probar el GA aplicado al TSP
 * @author Ines
 * @version 2019.10.*
 */
public class TesterTSP {

	
	public static void main(String[] args) {
		ProblemaTSP prob = new ProblemaTSP("brazil58.tsp.txt");
		// OPERADORES
		// operador para calcular el fitness
		Fitness<Integer> fitnessF = new FitnessTSP(prob);
		// operador para generar cromosomas aleatorios
		OpGeneracion<Integer> opGen = new OpGenRandNoRep<Integer>( prob.getAlfabeto(), prob.getNumCiudades() );
		// operador de cruce: (des)comentar segun el que se quiera usar
		OpCruce<Integer> opCruce = new OpCruce1PuntoNoRep<Integer>();
		//OpCruce<Integer> opCruce = new OpCruce2PuntosNoRep<Integer>();
		// operador de mutacion
		OpMutacion<Integer> opMut = new OpMutacionSwap<Integer>();
		// operador de seleccion: (des)comentar segun el que se quiera usar
		//OpSeleccion<Integer> opSel = new OpSelRuleta<Integer>();
		OpSeleccion<Integer> opSel = new OpSelRandom<Integer>();
		// operador de decodificacion
		OpDecodTSP decoder = new OpDecodTSP(prob);
		// PARAMETROS
//		int maxIter = 10000; // criterio de parada
		int maxIter = 20;
		double pc = 0.9; // prob cruce
		double pm = 0.3; // prob mutacion
		int tamPob = 10000; // tamanio poblacion
		
		// ALGORITMO GENETICO
		AlgoritmoGenetico<Integer> ga =
				new AlgoritmoGenetico<Integer>(prob.getNumCiudades(), prob.getAlfabeto(), pc, pm, tamPob);
		Individuo<Integer> cromoSol = 
				ga.lanzaGA(opGen, fitnessF, maxIter, opCruce, opMut, opSel);
		SolucionTSP solucion = decoder.apply(cromoSol);
		System.out.println("Solucion final: \n" + solucion);
		System.out.println("Coste: " + solucion.getCoste());
		
	}

}
