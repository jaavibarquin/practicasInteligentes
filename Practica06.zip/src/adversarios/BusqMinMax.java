/**
 * Clase BusqMinMax que extiende la BusquedaA para realizar busqueda con adversarios utilizando el algoritmo minimax
 */
package adversarios;

import java.util.ArrayList;
import java.util.List;

/**
 * @param Estado, el tipo de los estados del juego
 * @param Accion, el tipo de las acciones aplicables en un estado (movimientos)
 * @param Jugador, el tipo de los jugadores
 * @author ines
 * @version 2019.11
 */
public class BusqMinMax<Estado,Accion,Jugador> extends BusquedaA<Estado,Accion,Jugador>{

	/**
	 * Constructor
	 * @param juego, el Juego a jugar
	 */
	public BusqMinMax( Juego<Estado,Accion,Jugador> juego ) {
		super( juego );
	}

	/* (non-Javadoc)
	 * @see adversarios.BusquedaA#decideJugada(java.lang.Object, java.lang.Object)
	 */
	public Accion decideJugada( Estado e ) {
		Jugador max = getJuego().jugador(e); // max es el jugador al que le toca mover en el estado e
		List<Accion> acciones = getJuego().acciones(e); // posibles acciones/movimientos en el estado e

		double valor = Double.NEGATIVE_INFINITY;
		Accion ac = null;
		for (Accion a: acciones) {
			if (valor < minValor(juego.resultado(e, a), max)) {
				valor = minValor(juego.resultado(e, a), max);
				ac = a;
			}
		}
		// hay que encontrar la accion que proporciona maxima utilidad al jugador max
		// usando el algoritmo minimax
		return ac;
	}
	
	// Habra que aniadir metodos para hallar el maxvalor y el minvalor
	private double maxValor( Estado s, Jugador j ) {
		
		if (juego.terminalTest(s)) {
			return juego.utilidad(s, j);
		}
		
		// Calculamos el maximo valor de los hijos
		
		double v = Double.NEGATIVE_INFINITY;
		for (Accion a: juego.acciones(s)) {
			v = Math.max(v, minValor(juego.resultado(s, a), j));
		}
		
		return v;
	}
	
	private double minValor( Estado s, Jugador j ) {
		
		if (juego.terminalTest(s)) {
			return juego.utilidad(s, j);
		}
		
		// Calculamos el minimo valor de los hijos
		
		double v = Double.POSITIVE_INFINITY;
		for (Accion a: juego.acciones(s)) {
			v = Math.min(v, maxValor(juego.resultado(s, a), j));
		}
		
		return v;
	}
}
